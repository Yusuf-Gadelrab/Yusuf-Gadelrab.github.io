DHAHAB — LION MARK KIT
======================

The house mark of Yusuf Gadelrab (DHAHAB / ذهب — "gold").

FILES
  lion-mark.svg          master, gradient gold, transparent field
  lion-mark-flat.svg     one flat gold — small sizes and print
  lion-mark-bone.svg     bone on ink — dark garments and decks
  lion-mark-ink.svg      near-black on bone — light garments, paper
  lion-monogram.svg      mane with a YG monogram instead of a face
  lion-tile.svg          rounded app tile — favicons, home-screen icons
  lockup-*.svg           mark + wordmark, dark and light text variants
  avatar-*.png           square profile pictures (circular-crop safe)
  banner-*.png           LinkedIn / X / generic header images

RULES
  1. Two colourways only: gold on black, or ink on bone. Never a third.
  2. Clear space of one ear-width (~12% of the mark) on every side.
  3. Minimum 24px for the master mark, 16px for the tile. Below that, use the tile.
  4. Never recolour individual shards, add an outline, stretch it unevenly, or
     place it on a busy photograph.
  5. The gradient runs light-to-dark, top to bottom. It never rotates.

Full spec: https://yusuf-gadelrab.github.io/brand.html
© 2026 Yusuf Gadelrab. The mark is his identity — use it to refer to him or his
work, not as your own brand.
